package jp.co.sss.sys;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CmindSysApplication {

	public static void main(String[] args) {
		SpringApplication.run(CmindSysApplication.class, args);
	}

}
